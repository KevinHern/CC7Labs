<!DOCTYPE html>
<html>
<head>
	<title>Lab 02</title>
	
</head>
<body>
	<center>
		<?php
			error_reporting(0);
			ini_set('display_errors', 0);
			$opt = -1;
			$opt = $_GET["opt"];
			if ($opt == 1)
			{
				try {
					$m = new MongoClient();

					$db = $m->cc6;
					$collection = $db->mycol;

					$title = $_GET["eq"];
					$latex = $_GET["latex"];
					$document = array( 
					  "equation" => $eq, 
					  "lcode" => $latex
					);

					$collection->insert($document);
					echo "Ecuacion ingresada exitosamente";
				} catch (Exception $e) {
					echo "Algo salio mal";
				}
				finally
				{
					echo "<br>";
					echo "<br>";
					echo "<br>";
					echo "<a href=\"latex.php?opt=-1\">Regresar</a>";
				}
			}
			elseif ($opt == 2)
			{
				$m = new MongoClient();
				$db = $m->cc6;
				$collection = $db->mycol;
				$cursor = $collection->find();
				echo "<form name=\"hola\" action=\"latex.php\" method=\"GET\">";
				echo "<input type=\"number\" name=\"opt\" value=\"3\" hidden>";
				

				echo "<select name=\"displ\">";
				echo "<option disabled selected value>-- Escoger --</option>";
				foreach ($cursor as $document) {
					$name = $document["equation"];
					$code = $document["lcode"];
					echo "<option value =\"$code\">$name</option>";
				}
				echo "</select>";
				echo "<br>";
				echo "<input type=\"submit\" name=\"Submit\" value=\"Ver\">";
				echo "</form>";
				echo "<br>";


				echo "<br>";
				echo "<br>";
				echo "<br>";

				echo "<a href=\"latex.php?opt=-1\">Regresar</a>";
			}
			elseif($opt == 3)
			{
				$eq = $_GET["displ"];
				echo "$$ $eq $$";
				echo "<br>";
				echo "<br>";
				echo "<br>";

				echo "<a href=\"latex.php?opt=2\">Regresar</a>";
			}
			else
			{
				$opt = -1;
				echo "<form name=\"hola\" action=\"latex.php\" method=\"GET\">";
				echo "Nombre de la formula:";
				echo "<input type=\"number\" name=\"opt\" value=\"1\" hidden>";
				echo "<input type=\"text\" name=\"eq\" required><br>";
				echo "LaTeX:";
				echo "<input type=\"text\" name=\"latex\" required><br>";
				echo "<input type=\"submit\" name=\"Submit\" value=\"Store\">";
				echo "</form>";
				
				echo "<br>";
				echo "<br>";
				echo "<br>";
				echo "<a href=\"latex.php?opt=2\">Obtener Formulas</a>";
			}
		?>
		
	</center>

</body>
</script>
<script type="text/x-mathjax-config">
  MathJax.Hub.Config({tex2jax: {inlineMath: [['$','$'], ['\\(','\\)']]}});
</script>
<script type="text/javascript"
  src="http://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/MathJax.js?config=TeX-AMS-MML_HTMLorMML">
</script>
</html>